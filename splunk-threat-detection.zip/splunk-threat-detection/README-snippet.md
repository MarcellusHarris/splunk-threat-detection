## Splunk Threat Detection

This repository contains search queries and visualisations for detecting common attack techniques in Splunk. The provided SPL snippets cover PowerShell obfuscation, encoded commands, lateral movement, and failed administrator logins.

### Quick Start

1. **Saved searches:** Copy the `.spl` files from the `spl/` folder into Splunk’s *Search & Reporting* app and save them as saved searches. Adjust the `index` and `sourcetype` values to suit your deployment.  
2. **Dashboard:** Create a dashboard that references these saved searches. Place any exported images in the `screenshots/` directory.  
3. **Import & share:** Splunk dashboards can be imported via XML or JSON. Include a brief *How to import* section in your README when packaging this for others.

### Screenshots

The `screenshots/` folder contains sample views to illustrate what the dashboard might look like:

- `dashboard.png` – an overview of the threat detection dashboard.  
- `powershell-alert.png` – a detail view of a PowerShell obfuscation alert.

These are illustrative images created for this example; replace them with real exports from your Splunk environment.
