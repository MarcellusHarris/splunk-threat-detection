# Agent Playbook for Splunk Threat Detection

1. **Verify queries:** Test each SPL file in `spl/` against a Splunk environment to ensure they run without syntax errors and produce useful results.
2. **Dashboard:** Keep exported dashboard images up to date; replace the illustrative `dashboard.png` and `powershell-alert.png` with real screenshots after running the searches.
3. **README maintenance:** Ensure the README contains import instructions for dashboards and saved searches, and update the list of queries when new detections are added.
4. **Examples:** Consider adding sample logs or search results under `/examples/` to help others understand expected output.
5. **Issues:** Create issues for missing exports, outdated queries or additional detection ideas.
