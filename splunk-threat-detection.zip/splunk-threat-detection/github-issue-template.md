### Splunk Threat Detection TODOs

Use this issue to track final tasks for this repository:

- [ ] **Screenshots folder:** Create a `screenshots/` directory and add `dashboard.png` and `powershell-alert.png` (replace the current PDF reference with real PNG files).
- [ ] **SPL queries:** Commit search queries in a `spl/` folder for detecting PowerShell obfuscation, encoded commands, lateral movement, and failed administrator logins.
- [ ] **README update:** Add a “How to import dashboard & saved searches” section and link to the screenshots. Provide context on adjusting `index` and `sourcetype` values.
- [ ] **Dashboard export:** Optionally include an XML/JSON export of the dashboard to make it easy to import into Splunk.
